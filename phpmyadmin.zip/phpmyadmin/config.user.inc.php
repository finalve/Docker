<?php
$cfg['UploadDir'] = '';
$cfg['SaveDir'] = '';
ini_set('memory_limit', '5G');
ini_set('post_max_size', '5G');
ini_set('upload_max_filesize', '5G');
